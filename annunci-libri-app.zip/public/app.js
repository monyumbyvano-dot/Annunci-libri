async function fetchJSON(url){ const r = await fetch(url); return r.json(); }

async function loadClasses(){
  const classes = await fetchJSON('/api/classes');
  const indirizzoSel = document.getElementById('indirizzo');
  const annoSel = document.getElementById('anno');
  const classSelect = document.getElementById('class-select');
  // build options
  const byInd = {};
  classes.forEach(c=>{
    if(!byInd[c.indirizzo]) byInd[c.indirizzo]=[];
    byInd[c.indirizzo].push(c);
    const opt = document.createElement('option');
    opt.value = c.id;
    opt.textContent = c.indirizzo + ' - ' + c.anno + 'ª';
    classSelect.appendChild(opt);
  });
  Object.keys(byInd).forEach(ind=>{
    const opt = document.createElement('option');
    opt.value = ind;
    opt.textContent = ind;
    indirizzoSel.appendChild(opt);
    // anni unique
    const years = [...new Set(byInd[ind].map(x=>x.anno))].sort();
    years.forEach(y=>{
      const o = document.createElement('option');
      o.value = y;
      o.textContent = y + 'ª';
      annoSel.appendChild(o);
    });
  });
}

async function loadAnnouncements(){
  const q = document.getElementById('search').value;
  const indirizzo = document.getElementById('indirizzo').value;
  const anno = document.getElementById('anno').value;
  const type = document.getElementById('type').value;
  const params = new URLSearchParams();
  if(indirizzo) params.set('indirizzo', indirizzo);
  if(anno) params.set('anno', anno);
  if(type) params.set('type', type);
  if(q) params.set('q', q);
  const list = await fetchJSON('/api/announcements?' + params.toString());
  const container = document.getElementById('listing');
  container.innerHTML = '';
  if(list.length===0){ container.innerHTML = '<p>Nessun annuncio trovato.</p>'; return; }
  list.forEach(a=>{
    const card = document.createElement('div'); card.className='card';
    const h = document.createElement('h3'); h.textContent = a.title || '(Titolo non specificato)';
    const meta = document.createElement('div'); meta.className='meta';
    meta.textContent = (a.type==='vendita'?'Vendo':'Cerco') + ' — ' + (a.class_indirizzo? a.class_indirizzo + ' ' + a.class_anno + 'ª':'' ) + (a.price? ' — €'+a.price:'');
    const desc = document.createElement('p'); desc.textContent = a.description || '';
    const contactBtn = document.createElement('button'); contactBtn.textContent = 'Dettagli';
    contactBtn.onclick = ()=> showDetail(a.id);
    card.appendChild(h); card.appendChild(meta); card.appendChild(desc); card.appendChild(contactBtn);
    container.appendChild(card);
  });
}

async function showDetail(id){
  const ann = (await fetchJSON('/api/announcements?' + new URLSearchParams({q:'',}))).find(x=>x.id==id);
  // naive: fetch single by listing and filter (backend minimal). Alternatively implement /api/announcements/:id
  if(!ann) { alert('Annuncio non trovato'); return; }
  document.getElementById('listing').classList.add('hidden');
  document.getElementById('filters').classList.add('hidden');
  document.getElementById('detail-section').classList.remove('hidden');
  const d = document.getElementById('detail');
  d.innerHTML = '';
  const h = document.createElement('h2'); h.textContent = ann.title;
  const meta = document.createElement('div'); meta.className='meta'; meta.textContent = (ann.type==='vendita'?'Vendo':'Cerco') + ' • ' + (ann.class_indirizzo? ann.class_indirizzo + ' ' + ann.class_anno + 'ª':'');
  const p = document.createElement('p'); p.textContent = ann.description || '';
  d.appendChild(h); d.appendChild(meta); d.appendChild(p);
  if(ann.contact_visible){
    const contact = document.createElement('div');
    contact.innerHTML = '<strong>Contatto:</strong><br/>' + (ann.first_name? ann.first_name+' '+ann.last_name+'<br/>':'') + (ann.email? ann.email+'<br/>':'') + (ann.phone? ann.phone+'<br/>':'');
    d.appendChild(contact);
  } else {
    const btn = document.createElement('button'); btn.textContent = 'Richiedi contatto via email';
    btn.onclick = ()=> window.location.href = 'mailto:'+ (ann.email || '');
    d.appendChild(btn);
  }
}

document.getElementById('apply').addEventListener('click', loadAnnouncements);
document.getElementById('new-ann').addEventListener('click', ()=>{
  document.getElementById('form-section').classList.remove('hidden');
  document.getElementById('filters').classList.add('hidden');
  document.getElementById('listing').classList.add('hidden');
});
document.getElementById('cancel').addEventListener('click', (e)=>{ e.preventDefault(); document.getElementById('form-section').classList.add('hidden'); document.getElementById('filters').classList.remove('hidden'); document.getElementById('listing').classList.remove('hidden');});

document.getElementById('ann-form').addEventListener('submit', async (e)=>{
  e.preventDefault();
  const fd = new FormData(e.target);
  const obj = {};
  fd.forEach((v,k)=> obj[k] = v);
  obj.contact_visible = !!fd.get('contact_visible');
  const res = await fetch('/api/announcements', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(obj)});
  if(!res.ok){ alert('Errore nella pubblicazione'); return; }
  alert('Annuncio pubblicato!');
  e.target.reset();
  document.getElementById('form-section').classList.add('hidden');
  document.getElementById('filters').classList.remove('hidden');
  document.getElementById('listing').classList.remove('hidden');
  loadAnnouncements();
});

document.getElementById('back').addEventListener('click', ()=>{
  document.getElementById('detail-section').classList.add('hidden');
  document.getElementById('filters').classList.remove('hidden');
  document.getElementById('listing').classList.remove('hidden');
});

// init
(async ()=>{
  await loadClasses();
  await loadAnnouncements();
})();
