# Annunci Libri - Prototipo

Questo è un prototipo minimo pronto per essere eseguito **localmente** o essere distribuito su un servizio come Render/Heroku/Vercel (con Node).

## Contenuto del progetto
- `server.js` - backend Express + SQLite (autoinizializza il DB)
- `public/` - frontend statico (HTML/JS/CSS)
- `package.json` - dipendenze e script
- `data.db` verrà creato automaticamente alla prima esecuzione

## Requisiti
- Node.js (versione 16+ raccomandata)

## Esecuzione locale
1. Estrai lo zip.
2. Apri il terminale nella cartella del progetto.
3. Esegui `npm install`.
4. Esegui `npm start`.
5. Apri nel browser `http://localhost:3000`.

## Note sul design e sulla sicurezza
- Prototipo pensato per uso interno alla scuola; non implementa autenticazione avanzata.
- Per limitare l'uso all'istituto: aggiungi una validazione lato server per accettare solo email con dominio scolastico.
- Per produzione valuta HTTPS, autenticazione vera (magic link o password), protezione rate-limit e moderazione.

## Come ottenere un link pubblico (opzioni rapide)
- Deploy su [Render](https://render.com) o [Railway](https://railway.app): crea un nuovo servizio Node, carica il repo e imposta `npm install` e `npm start`.
- Su Heroku (se disponibile): `git init`, `heroku create`, `git push heroku main`.
- Se vuoi, ti posso guidare passo passo o preparare i comandi esatti per deploy gratuito su Render; dimmi quale piattaforma preferisci.
